/**
 * 
 */



function test() {
	var userId = document.getElementById('id').value;
	var password = document.getElementById('pw').value;
	
	alert(userId + ":" + password);
}